import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  TrendingUp, 
  Target, 
  LineChart, 
  HeartHandshake, 
  ShieldAlert, 
  ArrowRight, 
  RefreshCcw, 
  Briefcase,
  AlertCircle,
  CheckCircle2,
  XCircle,
  Lightbulb,
  Presentation
} from 'lucide-react';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// --- DATA ---

const ROUNDS = [
  {
    title: "The Retention Problem",
    investor: "The Skeptic",
    prompt: "You're claiming a $5B market, but 8% of your users are walking out the door every month. That doesn't scream product-market fit. Why are people leaving?",
    choices: [
      { text: "That 8% is mostly legacy users from our beta. If you look at our core cohort from the last quarter, net revenue retention is actually 112%.", type: "Confident", s: 7, sk: 18, v: 4, c: 11,
        feedback: "Perfect. You didn't hide from the bad number; you contextualized it with deeper data. The Skeptic loves this." },
      { text: "Some early dropout is natural. Once we ship our AI features next month, users won't be able to imagine working without us.", type: "Assertive", s: 11, sk: -11, v: -4, c: 4,
        feedback: "You made a bold promise about a feature that doesn't exist yet. The Shark likes the aggression, but the Skeptic hates hypotheticals." },
      { text: "We've been personally calling every user who left to understand their pain points. We are deeply committed to making this product perfect for them.", type: "Empathetic", s: -7, sk: -4, v: 14, c: 0,
        feedback: "It's great that you care, but caring doesn't fix a leaky bucket. The panel wants to hear solutions, not just empathy." },
      { text: "Honestly, our competitors are heavily subsidizing their product right now. It's hard to keep users when the other guys are giving it away for free.", type: "Defensive", s: -14, sk: -11, v: -7, c: -14,
        feedback: "Never blame the competition for losing users. It makes you look powerless and breaks your confidence." }
    ]
  },
  {
    title: "The Co-Founder Dispute",
    investor: "The Visionary",
    prompt: "I noticed your technical co-founder left the company three months ago. That's usually a massive red flag. What really happened?",
    choices: [
        { text: "We realized our visions for the company's culture fundamentally diverged. It was a painful split, but we handled it amicably to protect the team's morale.", type: "Empathetic", s: 4, sk: 4, v: 18, c: 7,
          feedback: "Excellent. Startups are human endeavors. You showed maturity, vulnerability, and leadership. The Visionary trusts you completely." },
        { text: "He couldn't scale. The code was getting sloppy, so I bought him out and brought in a fractional CTO who is significantly better.", type: "Assertive", s: 14, sk: 4, v: -18, c: 7,
          feedback: "Ruthless. The Shark respects the tough call, but the Visionary is horrified by how coldly you speak of a former partner." },
        { text: "According to our vesting schedule, we retained 80% of his equity. Operationally, our sprint velocity has actually increased by 15% since his departure.", type: "Confident", s: 4, sk: 11, v: -7, c: 4,
          feedback: "You answered a human question with an equity cap table. It's legally sound, but it lacks the emotional intelligence needed here." },
        { text: "It's a private legal matter that is protected by an NDA, so I'd rather not discuss the details. The company is fine.", type: "Defensive", s: -11, sk: -18, v: -14, c: -11,
          feedback: "Evasion breeds suspicion. The panel now assumes the worst, and the Skeptic thinks there's a hidden lawsuit waiting to happen." }
    ]
  },
  {
    title: "The Goliath Threat",
    investor: "The Shark",
    prompt: "Amazon just announced a $100M fund for this exact sector. They can bleed money for years. Why shouldn't I just bet on them?",
    choices: [
        { text: "Because Amazon builds products for everyone; we build a weapon for a specific niche. By the time they understand this customer, we'll own the infrastructure.", type: "Assertive", s: 18, sk: 7, v: 4, c: 11,
          feedback: "Boom. You drew a line in the sand. VCs want founders who aren't afraid of giants. The Shark is fully on board." },
        { text: "Our customer acquisition cost is currently $14, while the industry average for large enterprises is $45. We are simply more capital efficient.", type: "Confident", s: 4, sk: 11, v: 0, c: 4,
          feedback: "Good metrics, but capital efficiency doesn't stop Amazon from crushing you with a loss-leader. It's a bit naive." },
        { text: "We believe there's room in the market for multiple players. Amazon will validate the space, and we'll provide the community-focused alternative.", type: "Empathetic", s: -14, sk: -7, v: 11, c: -4,
          feedback: "The Shark rolls their eyes. 'Room for everyone' is a lifestyle business answer, not a venture-backed startup answer." },
        { text: "We have a first-mover advantage, and honestly, big tech companies fail at new initiatives all the time. Just look at the Fire Phone.", type: "Defensive", s: -11, sk: -14, v: -7, c: -11,
          feedback: "Hoping your competitor makes a mistake is not a strategy. You lost credibility." }
    ]
  },
  {
    title: "The Sudden Pivot",
    investor: "The Skeptic",
    prompt: "Six months ago, you pitched this as a direct-to-consumer app. Now you are 100% B2B Enterprise. That's a massive pivot. Are you just throwing things at the wall to see what sticks?",
    choices: [
      { text: "It wasn't a guess; it was math. Our B2C acquisition cost was $45 with a $30 LTV. Our B2B pilots are showing a $500 CAC with a $12,000 LTV. The data dictated the pivot.", type: "Confident", s: 7, sk: 21, v: 4, c: 11, 
        feedback: "Flawless logic. You proved that you listen to the market rather than your own ego. The Skeptic is highly impressed." },
      { text: "B2C is a bloodbath right now. We realized we were fighting for pennies, so we killed that division and went hunting for enterprise whales where the real budgets are.", type: "Assertive", s: 14, sk: -4, v: -11, c: 7, 
        feedback: "Strong, but a bit blunt. The Shark likes that you follow the money, but the Visionary worries you have no real attachment to your product." },
      { text: "We spent a lot of time talking to our early users, and realized the actual pain point was with their employers. We pivoted to serve the people who needed us most.", type: "Empathetic", s: -11, sk: -7, v: 14, c: 4, 
        feedback: "A nice sentiment, but investors want to know how you'll make money, not just who you are helping. The Shark thinks you're too soft." },
      { text: "We didn't want to pivot, but we ran out of marketing budget to acquire consumers. We had no other choice but to try pitching to businesses.", type: "Defensive", s: -18, sk: -14, v: -7, c: -21, 
        feedback: "You just admitted you only pivoted because you failed at your original plan and ran out of cash. Confidence shattered." }
    ]
  },
  {
    title: "The Burn Rate",
    investor: "The Shark",
    prompt: "You are burning $120k a month and only have 5 months of runway left. If the macro economy tanks and we don't fund you today, are you bankrupt by Q3?",
    choices: [
      { text: "No. We've drafted a 'cockroach' contingency plan. If we don't close, we instantly freeze hiring, cut marketing, and founders pause salaries, extending our runway to 14 months.", type: "Cautious", s: 11, sk: 18, v: 11, c: 11, 
        feedback: "Excellent. Being protective of the company's survival shows immense maturity. You proved you are a responsible steward of capital." },
      { text: "We aren't planning for failure. We are in active due diligence with three other tier-one funds right now. We will close this round, with or without you.", type: "Assertive", s: 18, sk: -11, v: -7, c: 14, 
        feedback: "A massive bluff. The Shark respects the bravado, but the Skeptic knows that banking on un-signed term sheets is how startups die." },
      { text: "Our high burn is purely variable ad-spend driving our 20% MoM growth. If we turn off the ads tomorrow, we are actually default-alive and cash-flow break-even.", type: "Confident", s: 4, sk: 14, v: 0, c: 7, 
        feedback: "A very strong, data-backed answer. Knowing the difference between 'good burn' (growth) and 'bad burn' (overhead) reassures the Skeptic." },
      { text: "I've been transparent with our team. They are so dedicated to the mission that half of them agreed to take equity instead of cash if things get tight.", type: "Empathetic", s: -14, sk: -11, v: 18, c: 0, 
        feedback: "The Visionary loves the loyalty, but the Shark and Skeptic know that paying rent with 'mission' doesn't work. It's a weak financial strategy." }
    ]
  },
  {
    title: "The Regulatory Black Swan",
    investor: "The Skeptic",
    prompt: "The EU is drafting legislation that could outlaw your primary data extraction method next year. How exposed are you to this wipeout?",
    choices: [
        { text: "We take compliance incredibly seriously. We deliberately siloed European data and built a fallback API that relies entirely on zero-party, opt-in data.", type: "Cautious", s: 0, sk: 21, v: 7, c: 11,
          feedback: "Brilliant. In the face of legal ruin, being cautious and prepared is the highest form of competence. The Skeptic is thrilled." },
        { text: "We'll fight it. We've hired a lobbying firm in Brussels. You don't change the world by asking for permission; we're going to push through.", type: "Assertive", s: 11, sk: -18, v: -7, c: 4,
          feedback: "'Move fast and break things' doesn't work with international privacy law. The Skeptic views you as a massive liability." },
        { text: "Our current revenue from the EU is only 18%. Even if we have to shut down operations there entirely, our US growth still puts us at a $50M run rate.", type: "Confident", s: 4, sk: 7, v: -4, c: 4,
          feedback: "You correctly assessed the financial damage, but writing off an entire continent isn't exactly the growth story they want to hear." },
        { text: "We really believe that regulators will see the societal value our tool provides once we explain it to them.", type: "Empathetic", s: -11, sk: -14, v: 4, c: -7,
          feedback: "Dangerously naive. Regulators don't care about your good intentions. The panel questions your grip on reality." }
    ]
  },
  {
    title: "The Lowball Offer",
    investor: "The Shark",
    prompt: "You want $3M on a $15M cap. That's priced for perfection. I'll give you the $3M, but I want 35% of the company. Take it or leave it.",
    choices: [
        { text: "Leave it. We have the metrics to justify the $15M cap, and we are talking to three other firms this week. We want you, but not at that price.", type: "Assertive", s: 14, sk: 4, v: -4, c: 14,
          feedback: "A power move. You risked the deal to hold your valuation. The Shark respects the walk-away power." },
        { text: "Our financial models show that giving up 35% now ruins the equity pool for future key hires. We can offer 22%, which aligns with standard Series Seed dilution.", type: "Confident", s: 4, sk: 18, v: 7, c: 7,
          feedback: "You negotiated using logic and industry standards. It cools the tension and keeps the Skeptic engaged." },
        { text: "We want a partner, not a boss. If we start this relationship with an aggressive cram-down, we won't have the trust required to build something massive.", type: "Empathetic", s: -7, sk: 0, v: 18, c: 4,
          feedback: "You framed the negotiation around the relationship. The Visionary loves this, though the Shark thinks you're being sentimental." },
        { text: "That's way too much equity... if we give up that much, the founders won't have enough motivation to keep working hard.", type: "Defensive", s: -18, sk: -11, v: -7, c: -21,
          feedback: "Whining about your motivation makes you look weak. VCs will eat you alive. You stumbled at the finish line." }
    ]
  }
];

// --- COMPONENTS ---

interface StatProps {
  label: string;
  value: number;
  color: string;
  icon: React.ReactNode;
  delay?: number;
}

function StatBar({ label, value, color, icon, delay = 0 }: StatProps) {
  return (
    <div className="flex flex-col gap-2 w-full">
      <div className="flex justify-between items-center text-sm font-medium text-slate-300">
        <div className="flex items-center gap-2">
          {icon}
          <span>{label}</span>
        </div>
        <span className="font-bold text-white">{value}%</span>
      </div>
      <div className="h-2.5 w-full bg-slate-800 rounded-full overflow-hidden border border-slate-700">
        <motion.div
          className={cn("h-full rounded-full")}
          style={{ backgroundColor: color }}
          initial={{ width: 0 }}
          animate={{ width: `${value}%` }}
          transition={{ duration: 0.8, ease: "easeOut", delay }}
        />
      </div>
    </div>
  );
}

function InvestorBadge({ investor }: { investor: string }) {
  const getInvestorConfig = () => {
    switch (investor) {
      case "The Shark":
        return { color: "bg-red-500/10 text-red-400 border-red-500/20", icon: <Target className="w-4 h-4" /> };
      case "The Skeptic":
        return { color: "bg-blue-500/10 text-blue-400 border-blue-500/20", icon: <LineChart className="w-4 h-4" /> };
      case "The Visionary":
        return { color: "bg-emerald-500/10 text-emerald-400 border-emerald-500/20", icon: <HeartHandshake className="w-4 h-4" /> };
      default:
        return { color: "bg-slate-500/10 text-slate-400 border-slate-500/20", icon: <Briefcase className="w-4 h-4" /> };
    }
  };

  const config = getInvestorConfig();

  return (
    <div className={cn("flex items-center gap-2 px-3 py-1.5 rounded-full border text-sm font-medium", config.color)}>
      {config.icon}
      {investor}
    </div>
  );
}

export default function App() {
  const [hasStarted, setHasStarted] = useState(false);
  const [currentRoundIndex, setCurrentRoundIndex] = useState(0);
  const [stats, setStats] = useState({ shark: 50, skeptic: 50, visionary: 50, conf: 0 });
  const [selectedChoice, setSelectedChoice] = useState<number | null>(null);
  const [shuffledChoices, setShuffledChoices] = useState<any[]>([]);
  const [isGameOver, setIsGameOver] = useState(false);

  useEffect(() => {
    if (hasStarted && !isGameOver) {
      // Shuffle choices for the current round
      const choices = [...ROUNDS[currentRoundIndex].choices];
      for (let i = choices.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [choices[i], choices[j]] = [choices[j], choices[i]];
      }
      setShuffledChoices(choices);
      setSelectedChoice(null);
    }
  }, [currentRoundIndex, hasStarted, isGameOver]);

  const avgTrust = Math.round((stats.shark + stats.skeptic + stats.visionary) / 3);

  const handleChoice = (index: number) => {
    if (selectedChoice !== null) return;
    
    setSelectedChoice(index);
    const choice = shuffledChoices[index];
    
    setStats(prev => ({
      shark: Math.max(0, Math.min(100, prev.shark + choice.s)),
      skeptic: Math.max(0, Math.min(100, prev.skeptic + choice.sk)),
      visionary: Math.max(0, Math.min(100, prev.visionary + choice.v)),
      conf: Math.max(0, Math.min(100, prev.conf + choice.c))
    }));
  };

  const nextRound = () => {
    if (currentRoundIndex < ROUNDS.length - 1) {
      setCurrentRoundIndex(prev => prev + 1);
    } else {
      setIsGameOver(true);
    }
  };

  const resetGame = () => {
    setStats({ shark: 50, skeptic: 50, visionary: 50, conf: 0 });
    setCurrentRoundIndex(0);
    setIsGameOver(false);
    setSelectedChoice(null);
    setHasStarted(false);
  };

  if (!hasStarted) {
    return (
      <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center p-6 text-slate-100 selection:bg-indigo-500/30">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="max-w-2xl w-full text-center space-y-8"
        >
          <div className="space-y-4">
            <div className="inline-flex items-center justify-center p-4 bg-indigo-500/10 rounded-full mb-4 border border-indigo-500/20">
              <Presentation className="w-12 h-12 text-indigo-400" />
            </div>
            <h1 className="text-5xl font-extrabold tracking-tight text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 via-purple-400 to-pink-400">
              Pitch Master<span className="align-super text-2xl">&trade;</span>
            </h1>
            <p className="text-xl text-slate-400 font-medium">VC Pitch Simulator</p>
          </div>

          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-8 text-left space-y-6 shadow-2xl">
            <h2 className="text-xl font-semibold text-slate-200">The Rules of the Room</h2>
            <ul className="space-y-4 text-slate-400">
              <li className="flex gap-3">
                <Target className="w-6 h-6 text-red-400 shrink-0" />
                <span><strong>The Shark</strong> wants scale, aggression, and power. Respect them, don't fear them.</span>
              </li>
              <li className="flex gap-3">
                <LineChart className="w-6 h-6 text-blue-400 shrink-0" />
                <span><strong>The Skeptic</strong> relies on data and risk mitigation. Be cautious and factual.</span>
              </li>
              <li className="flex gap-3">
                <HeartHandshake className="w-6 h-6 text-emerald-400 shrink-0" />
                <span><strong>The Visionary</strong> cares about mission, team, and empathy. Show your humanity.</span>
              </li>
            </ul>
            <div className="bg-slate-800/50 p-4 rounded-xl border border-slate-700/50 text-sm">
              <p className="text-slate-300">
                <strong className="text-white">Goal:</strong> Survive 7 rounds of questioning. You need at least <strong className="text-indigo-400">65% Investor Trust</strong> and <strong className="text-purple-400">40% Confidence</strong> to secure a term sheet.
              </p>
            </div>
          </div>

          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => setHasStarted(true)}
            className="px-8 py-4 bg-gradient-to-r from-indigo-500 to-purple-600 rounded-xl font-bold text-lg shadow-[0_0_40px_rgba(99,102,241,0.3)] hover:shadow-[0_0_60px_rgba(99,102,241,0.4)] transition-all"
          >
            Enter the Boardroom
          </motion.button>
        </motion.div>
      </div>
    );
  }

  if (isGameOver) {
    const isWin = avgTrust >= 65 && stats.conf >= 40;
    const isLossNoConfidence = stats.conf === 0 && avgTrust < 50;

    return (
      <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center p-4 md:p-8 text-slate-100">
        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="max-w-3xl w-full"
        >
          <div className="bg-slate-900 border border-slate-800 rounded-3xl overflow-hidden shadow-2xl">
            {/* Header */}
            <div className={cn("p-8 text-center border-b", 
              isWin ? "bg-emerald-500/10 border-emerald-500/20" : 
              isLossNoConfidence ? "bg-red-500/10 border-red-500/20" : 
              "bg-amber-500/10 border-amber-500/20"
            )}>
              {isWin ? (
                <>
                  <div className="inline-flex p-4 bg-emerald-500/20 rounded-full mb-4">
                    <CheckCircle2 className="w-12 h-12 text-emerald-400" />
                  </div>
                  <h1 className="text-4xl font-bold text-emerald-400 mb-2">Term Sheet Offered!</h1>
                  <p className="text-emerald-200/70 text-lg">You secured the investment. The panel was convinced by your pitch.</p>
                </>
              ) : isLossNoConfidence ? (
                <>
                  <div className="inline-flex p-4 bg-red-500/20 rounded-full mb-4">
                    <XCircle className="w-12 h-12 text-red-400" />
                  </div>
                  <h1 className="text-4xl font-bold text-red-400 mb-2">Pitch Failed</h1>
                  <p className="text-red-200/70 text-lg">You lost confidence and crumbled under pressure. The investors passed.</p>
                </>
              ) : (
                <>
                  <div className="inline-flex p-4 bg-amber-500/20 rounded-full mb-4">
                    <AlertCircle className="w-12 h-12 text-amber-400" />
                  </div>
                  <h1 className="text-4xl font-bold text-amber-400 mb-2">No Deal</h1>
                  <p className="text-amber-200/70 text-lg">You survived, but didn't build enough conviction. You need 65%+ Trust and 40%+ Confidence.</p>
                </>
              )}
            </div>

            <div className="p-8 space-y-10">
              <div className="space-y-6">
                <h3 className="text-xl font-semibold border-b border-slate-800 pb-2">Final Panel Sentiment</h3>
                <div className="space-y-6">
                  <StatBar label="The Shark (Aggression/Scale)" value={stats.shark} color="#ef4444" icon={<Target className="w-4 h-4" />} delay={0.1} />
                  <StatBar label="The Skeptic (Data/Risk)" value={stats.skeptic} color="#3b82f6" icon={<LineChart className="w-4 h-4" />} delay={0.2} />
                  <StatBar label="The Visionary (Team/Mission)" value={stats.visionary} color="#10b981" icon={<HeartHandshake className="w-4 h-4" />} delay={0.3} />
                </div>
              </div>

              <div className="space-y-6">
                <h3 className="text-xl font-semibold border-b border-slate-800 pb-2">Your Performance</h3>
                <div className="space-y-6">
                  <StatBar label="Investor Trust (Average)" value={avgTrust} color="#6366f1" icon={<ShieldAlert className="w-4 h-4" />} delay={0.4} />
                  <StatBar label="Investor Confidence" value={stats.conf} color="#a855f7" icon={<TrendingUp className="w-4 h-4" />} delay={0.5} />
                </div>
              </div>

              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={resetGame}
                className="w-full py-4 bg-slate-800 hover:bg-slate-700 text-white rounded-xl font-bold flex items-center justify-center gap-2 transition-colors border border-slate-700"
              >
                <RefreshCcw className="w-5 h-5" />
                Pitch Again
              </motion.button>
            </div>
          </div>
        </motion.div>
      </div>
    );
  }

  const round = ROUNDS[currentRoundIndex];

  return (
    <div className="min-h-screen bg-slate-950 flex flex-col md:flex-row text-slate-100 overflow-hidden font-sans">
      
      {/* Sidebar: Stats */}
      <div className="w-full md:w-80 bg-slate-900 border-b md:border-b-0 md:border-r border-slate-800 p-6 flex flex-col z-10 shrink-0">
        <div className="mb-8">
          <h1 className="text-2xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 to-purple-400 mb-1">
            Pitch Master
          </h1>
          <div className="flex items-center gap-2 text-slate-400 text-sm font-medium">
            <span className="bg-slate-800 px-2 py-1 rounded text-indigo-300">Round {currentRoundIndex + 1} of {ROUNDS.length}</span>
          </div>
        </div>

        <div className="space-y-8 flex-1">
          <div className="space-y-5">
            <h3 className="text-xs uppercase tracking-wider text-slate-500 font-bold mb-4">The Panel</h3>
            <StatBar label="The Shark" value={stats.shark} color="#ef4444" icon={<Target className="w-4 h-4" />} />
            <StatBar label="The Skeptic" value={stats.skeptic} color="#3b82f6" icon={<LineChart className="w-4 h-4" />} />
            <StatBar label="The Visionary" value={stats.visionary} color="#10b981" icon={<HeartHandshake className="w-4 h-4" />} />
          </div>

          <div className="pt-6 border-t border-slate-800 space-y-5">
            <h3 className="text-xs uppercase tracking-wider text-slate-500 font-bold mb-4">Overall Sentiment</h3>
            <StatBar label="Investor Trust" value={avgTrust} color="#6366f1" icon={<ShieldAlert className="w-4 h-4" />} />
            <StatBar label="Confidence" value={stats.conf} color="#a855f7" icon={<TrendingUp className="w-4 h-4" />} />
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col h-[calc(100vh-auto)] md:h-screen overflow-y-auto relative bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-slate-900 via-slate-950 to-slate-950">
        <div className="max-w-4xl w-full mx-auto p-6 md:p-10 lg:p-16 flex-1 flex flex-col justify-center min-h-max">
          
          <AnimatePresence mode="wait">
            <motion.div
              key={currentRoundIndex}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.3 }}
              className="space-y-8"
            >
              {/* Scenario */}
              <div className="bg-slate-900/80 backdrop-blur-sm border border-slate-800 rounded-3xl p-8 md:p-10 shadow-2xl relative overflow-hidden">
                <div className="absolute top-0 left-0 w-1 h-full bg-indigo-500"></div>
                <div className="mb-6 flex flex-wrap items-center justify-between gap-4">
                  <h2 className="text-2xl md:text-3xl font-bold text-white">{round.title}</h2>
                  <InvestorBadge investor={round.investor} />
                </div>
                <p className="text-lg md:text-xl text-slate-300 leading-relaxed">
                  "{round.prompt}"
                </p>
              </div>

              {/* Choices */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {shuffledChoices.map((choice, index) => {
                  const isSelected = selectedChoice === index;
                  const isDisabled = selectedChoice !== null && !isSelected;

                  return (
                    <motion.button
                      key={index}
                      whileHover={isDisabled ? {} : { scale: 1.02, y: -2 }}
                      whileTap={isDisabled ? {} : { scale: 0.98 }}
                      onClick={() => handleChoice(index)}
                      disabled={selectedChoice !== null}
                      className={cn(
                        "text-left p-6 rounded-2xl border transition-all duration-300 flex flex-col gap-3",
                        isSelected 
                          ? "bg-indigo-500/10 border-indigo-500 shadow-[0_0_20px_rgba(99,102,241,0.2)]" 
                          : isDisabled
                            ? "bg-slate-900/50 border-slate-800/50 opacity-40 cursor-not-allowed"
                            : "bg-slate-900 border-slate-800 hover:border-slate-600 hover:bg-slate-800/80 cursor-pointer"
                      )}
                    >
                      <div className="flex justify-between items-center w-full mb-1">
                        <span className={cn(
                          "text-xs font-bold uppercase tracking-wider px-2 py-1 rounded",
                          isSelected ? "bg-indigo-500 text-white" : "bg-slate-800 text-slate-400"
                        )}>
                          Option {index + 1}
                        </span>
                      </div>
                      <p className={cn(
                        "text-sm md:text-base leading-relaxed",
                        isSelected ? "text-indigo-100 font-medium" : "text-slate-300"
                      )}>
                        {choice.text}
                      </p>
                    </motion.button>
                  );
                })}
              </div>

              {/* Feedback Area */}
              <AnimatePresence>
                {selectedChoice !== null && (
                  <motion.div
                    initial={{ opacity: 0, y: 20, height: 0 }}
                    animate={{ opacity: 1, y: 0, height: 'auto' }}
                    className="overflow-hidden"
                  >
                    <div className="bg-slate-800/50 border border-slate-700 p-6 md:p-8 rounded-3xl mt-6 flex flex-col md:flex-row gap-6 items-start md:items-center justify-between shadow-xl">
                      <div className="flex gap-4 items-start">
                        <div className="mt-1 bg-slate-700 p-2 rounded-full shrink-0">
                          <Lightbulb className="w-6 h-6 text-yellow-400" />
                        </div>
                        <div>
                          <div className="text-xs uppercase tracking-wider text-slate-400 font-bold mb-1">
                            Feedback: {shuffledChoices[selectedChoice].type} Approach
                          </div>
                          <div 
                            className="text-slate-200 text-lg leading-relaxed font-medium"
                            dangerouslySetInnerHTML={{
                              __html: shuffledChoices[selectedChoice].feedback.replace(/\[.*?\]/, '')
                            }}
                          />
                        </div>
                      </div>

                      <motion.button
                        whileHover={{ scale: 1.05 }}
                        whileTap={{ scale: 0.95 }}
                        onClick={nextRound}
                        className="w-full md:w-auto shrink-0 px-8 py-4 bg-indigo-500 hover:bg-indigo-600 text-white font-bold rounded-xl flex items-center justify-center gap-2 transition-colors shadow-lg shadow-indigo-500/20"
                      >
                        {currentRoundIndex < ROUNDS.length - 1 ? 'Next Round' : 'See Results'}
                        <ArrowRight className="w-5 h-5" />
                      </motion.button>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>

            </motion.div>
          </AnimatePresence>
          
        </div>
      </div>
    </div>
  );
}
